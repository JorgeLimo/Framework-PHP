<?php

define('DEFAULT_CONTROLLER', 'index');
define('BASE_URL', 'http://localhost/Framework-PHP/');


define('DEFAULT_LAYOUT', 'default');

define('APP_NAME', 'Ourlimm training');
define('APP_SLOGAN', 'Descripcion');
define('APP_TITULO_PAGINA', 'Ourlimm training | ');
define('APP_COMPANY', 'http://www.ourlimm.training/');


define('EMAIL_MASTER', 'no-reply@ourlimm.training');

define('IDIOMA', 'en');

// nombre de la empresa | contacto
/** Variable de conexion **/
define('DB_HOST', 'localhost');
define('DB_NAME', 'cursophpg2');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHAR', 'utf8');



?>
