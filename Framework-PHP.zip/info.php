<?php 

echo phpinfo();

 ?>